package br.edu.unicid.aula0409;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import br.edu.unicid.aula0409.databinding.ActivityTela3Binding;

public class MainActivity extends AppCompatActivity {
    private Button btnIniciar;
    private Button btnResponder;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        Button btnIniciar = findViewById(R.id.btnIniciar);

        btnIniciar.setOnClickListener( v -> {
            Intent intent = new Intent(MainActivity.this, Tela2.class);
            startActivity(intent);
        });
        btnResponder.setOnClickListener( v -> {
            Intent intent = new Intent(MainActivity.this, ActivityTela3Binding.class);
            startActivity(intent);
        });
    }
}